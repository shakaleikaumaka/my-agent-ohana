# 🗿💻 totem-web v0.1 — the VIRTUAL ʻOhana Bot

*The ShanHaiWoo hackathon project after the 20 Oct pivot (`/workspace/shanhaiwoo-hackathon/PIVOT-VIRTUAL.md`):
the body is a 3D model + a manufacturing plan, the **mind is a thing judges can actually talk to**,
and the whole thing runs on one laptop for \$0.*

```
      [ browser totem — the body ]              [ local bridge — the mind ]
  3D totem, 6 faces, speaking face GLOWS   ←→   brain.py  → router.py (persona + pack)
  click a face / type / push-to-talk            canned.py (mock brain, ¥0, offline)
  six voices out (edge-tts, cached)             llm.py    (OpenRouter, optional)
  demo mode = scripted, zero network            memory.json (survives the plug pull)
```

## Run it

```bash
cd /workspace/ohana-totem
./build.sh                 # derive the page from the 3D source + syntax-gate
python3 prerender.py       # ONCE, on good wifi: bake the demo lines to mp3
python3 serve.py           # → http://127.0.0.1:8777/
python3 smoke.py           # 19 checks incl. a real SIGKILL power cycle (~30s)
```

### On Shaka's laptop (self-contained, no /shared, no Taurus)

```bash
./bundle.sh                # → /shared/ohana-bot/totem-web.tar.gz (3.6 MB)
# then, on the laptop:
tar xzf totem-web.tar.gz && cd totem-web
pip install -r requirements.txt       # flask + edge-tts (edge-tts only for NEW lines)
python3 serve.py                      # → http://127.0.0.1:8777/
```
The bundle carries its own `bridge/`, `personas/`, `packs/`, the pre-rendered demo mp3s and the
built page. Nothing is fetched at runtime.

| URL | what it is |
|---|---|
| `http://127.0.0.1:8777/` | the totem |
| `…/?demo=1` | arm + auto-run the 6-beat Demo Day script (offline-proof) |
| `…/?mute=1` | no voice (rehearsing without annoying the room) |
| `…/?q=high` / `?q=low` | pin the 3D quality step-down |
| `python3 serve.py --host 0.0.0.0` | judges/phones on the venue LAN |

## The party trick (tested, see REPORT)

```bash
#  …mid-conversation…
pkill -9 -f serve.py       # the cable comes out
python3 serve.py           # plug it back in
# reload the page → the face that was mid-thought glows and says:
#   "— the garden survived the dark, Mei 🌿 Before someone pulled my plug I was saying: …"
```
`memory.json` is written with `fsync` + atomic rename on every turn (router.VisitorMemory),
so a kill -9 can never leave it half-written.

## The brain ladder (ladder.py)

Three layers, climbed per request; the show can never fall off the bottom:

| layer | model | when it answers | cost |
|---|---|---|---|
| 1 **FREE** | `minimax/minimax-m3.1-flash:free` (OpenRouter) | key set, lane healthy | **¥0** |
| 2 **PAID** | `anthropic/claude-haiku-4.5` (the \$5 airbag) | free timed out / 429 / 5xx / bad json | cents |
| 3 **MOCK** | canned.py (persona + pack grounded, EN **+ 中文**) | no key, or both lanes dead | **¥0**, offline |

```bash
OHANA_LLM_KEY=sk-or-xxxx python3 serve.py     # one key powers both network lanes
# optional overrides:
#   OHANA_LLM_MODEL_FREE=…  OHANA_LLM_MODEL_PAID=…  OHANA_LLM_TIMEOUT=12
```

Failover rules: 12s hard timeout per attempt, 1 retry per lane, then the next
layer. **3 consecutive failed requests bench a lane for 5 minutes** (a dead
lane must not burn 24s of stage time on every question). `/health` reports the
full ladder state; the chat badge shows `free:minimax-m3.1-flash` /
`paid:claude-haiku-4.5` / `mock brain · ¥0`. No key = **zero sockets opened**
(proved by `test_ladder.py`, 18 checks against a local mock endpoint).
**The key lives ONLY in the environment — never in a file, never in git.**

MOCK is not a stub with fake text: it answers from the **real persona files**
(`/shared/ohana-bot/personas/*.md` greetings + example exchanges) and a curated keyword table whose
answers are condensed quotes of the **real domain packs** (mandate, Devcon facts, the chord lesson,
the songbook, the schedule). It also hands off across faces the way the router does — and since
2026-10-20 it does all of it **in natural simplified Chinese too**: any CJK character in the
visitor's message flips the whole mock path (answers, greetings, handoffs, nudges, name capture
"我叫…") to the 中文 tables, and `/tts` auto-picks a zh voice so Chinese text is never read by an
English voice (faces without their own `<face>_zh` pick in voices.json fall back to
`zh-CN-XiaoxiaoNeural`).

## Files

| file | job |
|---|---|
| `serve.py` | Flask bridge: the page, `/chat`, `/resume`, `/memory`, `/tts`, `/script`, `/health` |
| `brain.py` | imports the REAL `/shared/ohana-bot/bridge/router.py`; installs the `llm` + `taurus_sync` shims |
| `ladder.py` | the 3-layer brain: free OpenRouter model → paid haiku-4.5 → MOCK, with benching |
| `test_ladder.py` | 18 ladder checks against a local mock endpoint (no key, no network) |
| `canned.py` | the MOCK responder (persona + pack grounded, EN + 中文) |
| `tts.py` | edge-tts, disk-cached by sha1; voice picks live in `voices.json` |
| `demo_script.py` | the 6 beats, as data |
| `prerender.py` | bakes every demo line to `audio/demo/*.mp3` |
| `src/chat.js` | the chat lane (UI + glow driving + audio) |
| `src/build-page.py` | anchor-matched patcher: 3D source → `dist/index.html` |
| `dist/` | the shipped page (index.html + vendored three.js r160 + OrbitControls) |

**The 3D source stays where it is** (`/workspace/ohana-bot-3d/`, untouched, still the source of truth
for `/shared/public/ohana-bot/build/`). `src/build-page.py` patches a *copy* at build time with five
anchors and **refuses to build** if any anchor is missing or ambiguous.

## Laws obeyed

- **GFW:** zero runtime CDN fetches — the build fails if any `https://` script/style ref appears in the page.
- **No Taurus credentials:** `brain.py` replaces `taurus_sync` with a no-op module, so there is no
  code path to the platform even by accident (TESSERA-FINDINGS.md).
- **Never vocalize an error:** every reply passes `router.sanitize_reply()` (URL/path/token scrub,
  700-char cap, errors → canned in-persona line).
- **Bounded fetches:** every client call has an AbortController deadline (the wake-law scar).
- **No GPU here:** this container renders on SwiftShader; measured fps is a software floor.
  Nothing was stripped to chase it.

## Deploy (NOT run yet — Shaka's call)

```bash
# mirror the artifact into the public dashboard + the gh-pages site
rsync -a --delete /workspace/ohana-totem/dist/ /shared/public/ohana-bot/totem/
cd /workspace/gh-site && git pull --rebase \
  && rsync -a --delete /workspace/ohana-totem/dist/ ohana-bot/totem/ \
  && git add ohana-bot/totem && git commit -m "ohana bot: virtual totem (static body)" \
  && git push                        # → https://myagentohana.com/ohana-bot/totem/
```
⚠️ A deployed copy is the **body only**: the chat lane needs the local bridge
(`/chat`, `/tts`), so a static mirror shows the 3D totem and falls back to
"bridge not reachable". The talking totem is a laptop, by design.
