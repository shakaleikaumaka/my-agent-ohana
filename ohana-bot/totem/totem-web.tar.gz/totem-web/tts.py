#!/usr/bin/env python3
"""
tts.py — six voices out, cached on disk.

edge-tts (the same voices as the audition page). Every utterance is cached by
sha1(voice|text) so a line is only ever synthesized once; the demo lines are
pre-rendered by prerender.py and therefore need no network at all on stage.

Voice picks live in ONE file: voices.json. When Shaka picks his winners from
the audition page, edit that file — nothing else changes.
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import os
from pathlib import Path

HERE = Path(__file__).resolve().parent
CACHE = HERE / "audio" / "cache"
DEMO = HERE / "audio" / "demo"
VOICES_JSON = HERE / "voices.json"

DEFAULT_VOICES = {
    # audition Candidate A per face (see audio_io.EDGE_VOICES)
    "shaka": "en-US-AndrewNeural",
    "oso": "en-GB-RyanNeural",
    "deva": "en-GB-SoniaNeural",
    "crops": "en-GB-ThomasNeural",
    "kala": "en-NZ-MollyNeural",
    "oke": "en-US-GuyNeural",
    "shaka_zh": "zh-CN-YunxiNeural",
}

# small per-face delivery tweaks (edge-tts prosody) — OKE shouts, CROPS is calm
RATE = {"oke": "+12%", "crops": "-6%", "kala": "-4%", "shaka": "+2%",
        "oso": "+0%", "deva": "+0%"}


def voices() -> dict:
    if VOICES_JSON.exists():
        try:
            v = dict(DEFAULT_VOICES)
            v.update(json.loads(VOICES_JSON.read_text(encoding="utf-8")))
            return v
        except Exception as e:
            print(f"[tts] voices.json unreadable ({e}) — using defaults")
    return dict(DEFAULT_VOICES)


def voice_for(face: str, lang: str = "en") -> str:
    v = voices()
    if lang.startswith("zh"):
        # Chinese text must NEVER be read by an English voice: faces without
        # their own <face>_zh pick fall back to a neutral zh voice.
        return v.get(f"{face}_zh") or "zh-CN-XiaoxiaoNeural"
    return v.get(face, v["shaka"])


def key_for(face: str, text: str, lang: str = "en") -> str:
    voice = voice_for(face, lang)
    h = hashlib.sha1(f"{voice}|{RATE.get(face,'+0%')}|{text}".encode("utf-8")).hexdigest()[:20]
    return h


def cached_path(face: str, text: str, lang: str = "en") -> Path:
    CACHE.mkdir(parents=True, exist_ok=True)
    return CACHE / (key_for(face, text, lang) + ".mp3")


async def _synth(text: str, voice: str, out: Path, rate: str = "+0%"):
    import edge_tts
    tmp = out.with_suffix(".part")
    comm = edge_tts.Communicate(text, voice, rate=rate)
    await comm.save(str(tmp))
    if tmp.stat().st_size < 400:
        tmp.unlink(missing_ok=True)
        raise RuntimeError("edge-tts returned an empty stream")
    tmp.replace(out)


def synth(text: str, face: str, lang: str = "en", out: Path | None = None) -> Path:
    """Returns a path to an mp3. Raises on failure (callers degrade to silence)."""
    out = out or cached_path(face, text, lang)
    if out.exists() and out.stat().st_size > 400:
        return out
    out.parent.mkdir(parents=True, exist_ok=True)
    asyncio.run(_synth(text, voice_for(face, lang), out, RATE.get(face, "+0%")))
    return out


def ensure_voices_json():
    if not VOICES_JSON.exists():
        VOICES_JSON.write_text(json.dumps(DEFAULT_VOICES, indent=1) + "\n", encoding="utf-8")


if __name__ == "__main__":
    ensure_voices_json()
    p = synth("Aloha! This is the voice check.", "shaka")
    print("wrote", p, os.path.getsize(p), "bytes")
