#!/usr/bin/env python3
"""factory-info.py <port> [outfile] — ask the Seeed factory firmware's serial console (115200) for
`factory_info`, `version` and `read_mac`, save the answers. Best effort: times out quietly on other firmware.
pyserial comes with esptool, so nothing extra to install."""
import sys, time
try:
    import serial
except ImportError:
    print("pyserial missing (pip install pyserial)"); sys.exit(1)

port = sys.argv[1]
out = sys.argv[2] if len(sys.argv) > 2 else "factory_info.txt"
got = []
try:
    with serial.Serial(port, 115200, timeout=0.5) as s:
        s.dtr = False; s.rts = False   # don't yank the chip into bootloader
        time.sleep(0.3); s.reset_input_buffer()
        for cmd in ("\r\n", "factory_info\r\n", "version\r\n", "read_mac\r\n", "battery\r\n"):
            s.write(cmd.encode()); time.sleep(0.8)
            chunk = s.read(8192).decode("utf-8", "replace")
            if chunk.strip():
                got.append(f"> {cmd.strip() or '(enter)'}\n{chunk.strip()}")
except Exception as e:
    print(f"serial error: {e}"); sys.exit(1)

text = "\n\n".join(got).strip()
if not text or not any(k in text for k in ("eui", "EUI", "sn", "SN", "version", "mac", "MAC", "SenseCAP")):
    print("no console answer"); sys.exit(1)
open(out, "w", encoding="utf-8").write(text + "\n")
print(f"saved → {out}\n" + text[:600])
