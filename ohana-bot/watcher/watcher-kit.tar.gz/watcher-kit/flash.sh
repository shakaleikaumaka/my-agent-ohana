#!/usr/bin/env bash
# ʻOhana Watcher kit — flash the SenseCAP Watcher W1-A with xiaozhi-esp32 (SHAKA face)
# Mac / Linux. Needs: python3 + `pip install esptool` (any 4.x/5.x). Uses `python3 -m esptool`.
#
#   ./flash.sh                 # backup nvsfactory + FULL 32MB dump, then flash xiaozhi
#   ./flash.sh --skip-full     # backup nvsfactory only (3 s) — only if you are in a hurry
#   PORT=/dev/cu.wchusbserial5XXXX ./flash.sh   # pin the port instead of auto-probing
#
# LOANER LAW: the merged xiaozhi binary writes from 0x0 and covers 0x9000, where Seeed keeps the
# device identity (EUI / SenseCraft credentials). Without nvsfactory.bin the Watcher can NEVER
# rejoin SenseCraft again. This script refuses to flash until that backup exists and is 204800 bytes.
set -u
cd "$(dirname "$0")"
FW="xiaozhi/merged-binary.bin"
BK="backup"; mkdir -p "$BK"
ESP="python3 -m esptool"
SKIP_FULL=0; [ "${1:-}" = "--skip-full" ] && SKIP_FULL=1

say(){ printf '\n\033[1;36m%s\033[0m\n' "$*"; }
die(){ printf '\n\033[1;31mSTOP: %s\033[0m\n' "$*"; exit 1; }

[ -s "$FW" ] || die "missing $FW (unzip xiaozhi/watcher.zip)"
python3 -m esptool version >/dev/null 2>&1 || die "esptool not installed: pip3 install esptool   (China: pip3 install -i https://pypi.tuna.tsinghua.edu.cn/simple esptool)"

# ---- 1. find the ESP32-S3 port (the Watcher shows TWO UARTs: ESP32-S3 + Himax; probe each) ----
if [ -z "${PORT:-}" ]; then
  say "Probing serial ports for the ESP32-S3 (plug the BOTTOM/side USB-C — the back port is power only)"
  CANDS=$(ls /dev/cu.wchusbserial* /dev/cu.usbmodem* /dev/cu.usbserial* /dev/ttyACM* /dev/ttyUSB* 2>/dev/null)
  [ -n "$CANDS" ] || die "no serial ports found — data cable? bottom port? (Mac: ls /dev/cu.*)"
  for p in $CANDS; do
    printf '  %s … ' "$p"
    if $ESP --chip esp32s3 --port "$p" --before default_reset --after no_reset --no-stub chip_id 2>/dev/null | grep -q "ESP32-S3"; then
      echo "ESP32-S3 ✓"; PORT="$p"; break
    else echo "no"; fi
  done
  [ -n "${PORT:-}" ] || die "no port answered as ESP32-S3. Seeed hint: on Mac the ESP32 is usually the port with the BIGGER number; on Windows the COM ending in B. Try PORT=... ./flash.sh"
fi
say "Using port $PORT"
$ESP --chip esp32s3 --port "$PORT" --no-stub chip_id | tee "$BK/chip_id.txt" | grep -E "MAC|Chip is|Flash"

# ---- 2. backup identity partition (MANDATORY) ----
say "Backup 1/2 — nvsfactory (device identity, 0x9000 +200 KB)"
$ESP --chip esp32s3 --port "$PORT" --baud 921600 --before default_reset --after no_reset --no-stub \
     read_flash 0x9000 204800 "$BK/nvsfactory.bin" || die "nvsfactory backup failed"
SZ=$(wc -c < "$BK/nvsfactory.bin" | tr -d ' ')
[ "$SZ" = "204800" ] || die "nvsfactory.bin is $SZ bytes, expected 204800"
cp "$BK/nvsfactory.bin" "$BK/nvsfactory.$(date +%Y%m%d-%H%M%S).bin"
echo "  nvsfactory.bin ✓ ($SZ bytes) — keep this file forever"

# ---- 3. full 32 MB dump (exact restore image; ~6 min @921600) ----
if [ $SKIP_FULL = 0 ]; then
  say "Backup 2/2 — full 32 MB flash image (≈6 min; this is the 'hand it back exactly as received' file)"
  $ESP --chip esp32s3 --port "$PORT" --baud 921600 --before default_reset --after no_reset \
       read_flash 0x0 0x2000000 "$BK/watcher-factory-full.bin" || die "full dump failed (re-run, or ./flash.sh --skip-full)"
  SZ=$(wc -c < "$BK/watcher-factory-full.bin" | tr -d ' ')
  [ "$SZ" = "33554432" ] || die "full dump is $SZ bytes, expected 33554432"
  echo "  watcher-factory-full.bin ✓"
else
  say "Skipping the full dump (--skip-full). Restore will use Seeed's V1.1.7 bins + your nvsfactory.bin."
fi

# ---- 4. flash xiaozhi ----
say "Ready to write $FW at 0x0 (overwrites Seeed firmware; restore = ./restore.sh)"
printf 'Type FLASH to continue: '; read -r ans; [ "$ans" = "FLASH" ] || die "aborted"
$ESP --chip esp32s3 --port "$PORT" --baud 921600 --before default_reset --after hard_reset \
     write_flash 0x0 "$FW" || die "write failed — power-cycle (hold wheel 3 s) and re-run; nothing is lost while backups exist"

say "DONE. The Watcher reboots into XiaoZhi."
cat <<'EOF'
Next:
  1. Hold the wheel button ~3 s if the screen stays dark (power on).
  2. First boot = Wi-Fi setup: on your phone join Wi-Fi "Xiaozhi-xxxx" → captive page (or http://192.168.4.1)
     → pick a 2.4 GHz network (phone hotspot works; iPhone: Maximize Compatibility ON) → Connect.
     (To redo Wi-Fi later: single-click the wheel while the "starting" screen is up.)
  3. It speaks a 6-digit code (wake it with "你好小智" or single-click the wheel to re-hear it).
  4. xiaozhi.me → Console → Sign in with Google → 新建智能体 → 添加设备 → the code.
  5. Paste xiaozhi-role-prompt.txt into the agent's role settings, pick a voice, save. Say "你好小智" → "Aloha Shaka".
EOF
