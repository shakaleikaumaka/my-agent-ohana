#!/usr/bin/env bash
# ʻOhana Watcher kit — flash the SenseCAP Watcher W1-A with a xiaozhi-based talking-face firmware.
# Mac / Linux. Needs: python3 + `pip install esptool` (any 4.x/5.x). Uses `python3 -m esptool`.
#
#   ./flash.sh                 # community xiaozhi v2.5.2 (binds on xiaozhi.me, wake word 你好小智)   ← default, needs NO Seeed auth
#   ./flash.sh --seeed         # Seeed "Visual Trigger" v2.0.4 EN (binds on SenseCraft Watcher-Agent, wake "Jarvis",
#                              #   visual wake-up) — ONLY if the label says W1-A-EN or Seeed gave you the auth file
#   ./flash.sh --skip-full     # identity backup only (3 s), skip the 6-min full image
#   PORT=/dev/cu.wchusbserial5XXXX ./flash.sh   # pin the port instead of auto-probing
#
# LOANER LAW: both images write from 0x0 and cover 0x9000, where Seeed keeps the device identity
# (EUI / SenseCraft credentials). Without nvsfactory.bin the Watcher can NEVER rejoin SenseCraft.
# This script refuses to flash until that backup exists and is exactly 204800 bytes.
# NEVER burn eFuses on a loaner (Seeed's "authentication file" for non-EN units does) — ask the owner first.
set -u
cd "$(dirname "$0")"
FW="xiaozhi/merged-binary.bin"; FLAVOR="community xiaozhi-esp32 v2.5.2 (xiaozhi.me)"
BK="backup"; mkdir -p "$BK"
ESP="python3 -m esptool"
SKIP_FULL=0
for a in "$@"; do
  case "$a" in
    --skip-full) SKIP_FULL=1 ;;
    --seeed) FW="seeed-agent/merged-binary-en.bin"; FLAVOR="Seeed Visual-Trigger v2.0.4 EN (SenseCraft Watcher Agent)" ;;
    *) echo "unknown flag $a"; exit 2 ;;
  esac
done

say(){ printf '\n\033[1;36m%s\033[0m\n' "$*"; }
die(){ printf '\n\033[1;31mSTOP: %s\033[0m\n' "$*"; exit 1; }

[ -s "$FW" ] || die "missing $FW"
python3 -m esptool version >/dev/null 2>&1 || die "esptool not installed: pip3 install esptool   (China: pip3 install -i https://pypi.tuna.tsinghua.edu.cn/simple esptool)"

# ---- 1. find the ESP32-S3 port (the Watcher shows TWO UARTs: ESP32-S3 + Himax; probe each) ----
if [ -z "${PORT:-}" ]; then
  say "Probing serial ports for the ESP32-S3 (plug the BOTTOM/side USB-C — the back port is power only)"
  CANDS=$(ls /dev/cu.wchusbserial* /dev/cu.usbmodem* /dev/cu.usbserial* /dev/ttyACM* /dev/ttyUSB* 2>/dev/null)
  [ -n "$CANDS" ] || die "no serial ports found — data cable? bottom port? (Mac: ls /dev/cu.*)"
  for p in $CANDS; do
    printf '  %s … ' "$p"
    if $ESP --chip esp32s3 --port "$p" --before default_reset --after no_reset --no-stub chip_id 2>/dev/null | grep -q "ESP32-S3"; then
      echo "ESP32-S3 ✓"; PORT="$p"; break
    else echo "no (Himax side or not the Watcher)"; fi
  done
  [ -n "${PORT:-}" ] || die "no port answered as ESP32-S3. Seeed: Mac = the BIGGER-numbered port, Windows = COM ending in B. Try PORT=... ./flash.sh"
fi
say "Using port $PORT"
$ESP --chip esp32s3 --port "$PORT" --no-stub --after no_reset chip_id | tee "$BK/chip_id.txt" | grep -E "MAC|Chip is|Flash"
MAC=$(grep -m1 -oE 'MAC: *([0-9a-f]{2}:){5}[0-9a-f]{2}' "$BK/chip_id.txt" | sed 's/MAC: *//')
[ -n "$MAC" ] && echo "  STA MAC = $MAC  (this is what Seeed asks for if an auth file is ever requested)" && echo "$MAC" > "$BK/sta_mac.txt"

# ---- 1b. factory info from the Seeed console (best effort; only answers on the factory firmware) ----
if [ -x factory-info.py ] || [ -f factory-info.py ]; then
  say "Reading factory_info / version from the Seeed serial console (best effort)"
  python3 factory-info.py "$PORT" "$BK/factory_info.txt" || echo "  (no console answer — fine if the device is not on factory firmware)"
fi

# ---- 2. backup identity partition (MANDATORY) ----
say "Backup 1/2 — nvsfactory (device identity, 0x9000 +200 KB)"
$ESP --chip esp32s3 --port "$PORT" --baud 921600 --before default_reset --after no_reset --no-stub \
     read_flash 0x9000 204800 "$BK/nvsfactory.bin" || die "nvsfactory backup failed"
SZ=$(wc -c < "$BK/nvsfactory.bin" | tr -d ' ')
[ "$SZ" = "204800" ] || die "nvsfactory.bin is $SZ bytes, expected 204800"
cp "$BK/nvsfactory.bin" "$BK/nvsfactory.$(date +%Y%m%d-%H%M%S).bin"
echo "  nvsfactory.bin ✓ ($SZ bytes) — keep this file forever"

# ---- 3. full 32 MB dump (exact restore image; ~6 min @921600) ----
if [ $SKIP_FULL = 0 ]; then
  say "Backup 2/2 — full 32 MB flash image (≈6 min; the 'hand it back exactly as received' file)"
  $ESP --chip esp32s3 --port "$PORT" --baud 921600 --before default_reset --after no_reset \
       read_flash 0x0 0x2000000 "$BK/watcher-factory-full.bin" || die "full dump failed (re-run, or ./flash.sh --skip-full)"
  SZ=$(wc -c < "$BK/watcher-factory-full.bin" | tr -d ' ')
  [ "$SZ" = "33554432" ] || die "full dump is $SZ bytes, expected 33554432"
  echo "  watcher-factory-full.bin ✓"
else
  say "Skipping the full dump (--skip-full). Restore will use Seeed's V1.1.7 bins + your nvsfactory.bin."
fi

# ---- 4. flash ----
say "Ready to write: $FLAVOR"
echo "  file $FW → 0x0 (overwrites the current firmware; restore = ./restore.sh)"
printf 'Type FLASH to continue: '; read -r ans; [ "$ans" = "FLASH" ] || die "aborted"
$ESP --chip esp32s3 --port "$PORT" --baud 921600 --before default_reset --after hard_reset \
     write_flash 0x0 "$FW" || die "write failed — pin-press the reset hole (bottom) and re-run; nothing is lost while backups exist"

say "DONE — $FLAVOR written. If the screen stays dark: pin in the bottom reset hole, or hold the wheel 3–5 s."
if [ "$FW" = "xiaozhi/merged-binary.bin" ]; then cat <<'EOF'
Next (community xiaozhi):
  1. Phone → Wi-Fi "Xiaozhi-xxxx" → captive page (or http://192.168.4.1) → pick a 2.4 GHz network → Connect.
     (Redo Wi-Fi later: single-click the wheel while the "starting / Scanning Wi-Fi" screen is up.)
  2. Say "你好小智" (or single-click the wheel) → it speaks a 6-digit code (ask again to re-hear).
  3. xiaozhi.me → Console → Sign in with Google → 新建智能体 "SHAKA" → 添加设备 → the code.
  4. 配置角色 → paste xiaozhi-role-prompt.txt → pick a voice → save. MCP接入点 is on the same page (Path B).
EOF
else cat <<'EOF'
Next (Seeed Watcher Agent):
  1. Phone → Wi-Fi "Watcher-xxxx" → captive page (or http://192.168.4.1) → pick a 2.4 GHz network → Connect.
  2. It shows/speaks a 6-digit code. Wake word = "Jarvis" (fixed in firmware).
  3. https://sensecraft.seeed.cc/ai/watcher-agent → Continue with Google → Bind Device → the code.
     If binding fails with an auth error: this unit is not -EN and has no auth file → ./restore.sh, then use the default path.
  4. Agent config → role prompt (xiaozhi-role-prompt.txt) → voice → LLM → MCP Setting → Get MCP Endpoint (Path B).
  5. Visual wake-up: say "Jarvis, turn on the inference switch" (needs the Person model on the Himax chip — SenseCraft AI → Watcher workspace → port A).
EOF
fi
