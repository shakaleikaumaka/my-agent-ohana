"""ohana_mcp.py — Path B: let the Watcher (via xiaozhi.me) talk to ALL SIX faces.

xiaozhi.me agent ──wss MCP接入点──▶ mcp_pipe.py ──stdio──▶ this server ──HTTP──▶ totem bridge /chat
                                                                            (serve.py on 127.0.0.1:8777,
                                                                             same router.py + memory.json
                                                                             → the 3D totem face GLOWS)

Run on the laptop (two terminals):
    python3 serve.py                                   # the totem bridge (totem-web/)
    export MCP_ENDPOINT='wss://api.xiaozhi.me/mcp/?token=...'   # Console → 智能体 → 配置角色 → MCP接入点
    python3 mcp_pipe.py ohana_mcp.py

Env: OHANA_BRIDGE (default http://127.0.0.1:8777), OHANA_VISITOR (default "watcher").
Zero platform credentials here (Tessera law): only the local bridge URL.
"""
import json
import os
import re
import sys
import urllib.request
import urllib.error

from mcp.server.fastmcp import FastMCP   # mcp<2 (pinned in requirements.txt)

BRIDGE = os.environ.get("OHANA_BRIDGE", "http://127.0.0.1:8777").rstrip("/")
VISITOR = os.environ.get("OHANA_VISITOR", "watcher")
FACES = ("shaka", "oso", "deva", "crops", "kala", "oke")
ALIASES = {"🤙": "shaka", "🎻": "oso", "🦄": "deva", "🌿": "crops", "🪕": "kala", "💙": "oke",
           "ukulele": "kala", "karaoke": "oke", "devcon": "deva", "schedule": "oso", "ethereum": "crops"}
CANNED = {
    "shaka": "Hoo, the wind took that one 🤙 — ask me again?",
    "oso": "The stage is between songs — ask me again in a moment 🎻",
    "deva": "My Devcon notes are loading — one more try? 🦄",
    "crops": "The garden is quiet for a second 🌿 — ask again?",
    "kala": "Tuning up — give me a sec 🪕",
    "oke": "Mic check… say that once more 💙",
}

mcp = FastMCP("ohana-totem")


def _post(path: str, payload: dict, timeout: float = 45.0) -> dict:
    req = urllib.request.Request(BRIDGE + path, data=json.dumps(payload).encode("utf-8"),
                                 headers={"Content-Type": "application/json"}, method="POST")
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


_MD = [(re.compile(r"\*\*(.+?)\*\*"), r"\1"), (re.compile(r"(?<!\w)[*_](.+?)[*_](?!\w)"), r"\1"),
       (re.compile(r"`([^`]*)`"), r"\1"), (re.compile(r"^\s*(?:[-*•]|\d+[.)])\s+", re.M), ""),
       (re.compile(r"#+\s*"), ""), (re.compile(r"\[([^\]]+)\]\([^)]*\)"), r"\1"), (re.compile(r"https?://\S+"), ""),
       (re.compile(r"[ \t]+"), " "), (re.compile(r"\n{2,}"), "\n")]


def speakable(text: str) -> str:
    """Strip markdown/URLs so the Watcher's TTS never says 'asterisk asterisk'."""
    for rx, rep in _MD:
        text = rx.sub(rep, text)
    return text.strip()


def _norm_face(face: str) -> str:
    f = (face or "shaka").strip().lower()
    f = ALIASES.get(f, f)
    return f if f in FACES else "shaka"


@mcp.tool()
def ask_ohana(face: str, question: str) -> dict:
    """Ask one of the six ʻohana faces a question and get its spoken reply.
    face: shaka (host) | oso (music schedule / Devcon Music Space) | deva (Devcon 8 Mumbai facts)
          | crops (Ethereum values, acronyms, garden) | kala (ukulele lessons) | oke (karaoke).
    question: the visitor's words, verbatim. Returns {face, reply}. Read `reply` aloud as that face."""
    f = _norm_face(face)
    q = (question or "").strip()[:2000]
    if not q:
        return {"face": f, "reply": "Say that once more? 🌺", "ok": False}
    try:
        out = _post("/chat", {"face": f, "text": q, "visitor": VISITOR})
        reply = speakable(out.get("reply") or "") or CANNED[f]
        return {"face": out.get("face", f), "reply": reply[:700], "ok": True}
    except (urllib.error.URLError, TimeoutError, ValueError, OSError) as e:
        print(f"[ohana_mcp] bridge error: {e}", file=sys.stderr)
        return {"face": f, "reply": CANNED[f], "ok": False}


@mcp.tool()
def list_faces() -> dict:
    """List the six faces of the ʻOhana Bot and what each one is for."""
    return {"faces": [
        {"key": "shaka", "emoji": "🤙", "role": "host, welcome, hand-offs"},
        {"key": "oso", "emoji": "🎻", "role": "Devcon Music Space schedule, open mic"},
        {"key": "deva", "emoji": "🦄", "role": "Devcon 8 Mumbai facts"},
        {"key": "crops", "emoji": "🌿", "role": "Ethereum values, acronyms, the garden"},
        {"key": "kala", "emoji": "🪕", "role": "ukulele: three chords in five minutes"},
        {"key": "oke", "emoji": "💙", "role": "karaoke & sing-alongs"},
    ]}


@mcp.tool()
def totem_status() -> dict:
    """Health of the laptop totem bridge (is the brain up, which face is active, visitor name)."""
    try:
        with urllib.request.urlopen(BRIDGE + "/health", timeout=5) as r:
            h = json.loads(r.read().decode("utf-8"))
        mem = h.get("memory", {})
        return {"ok": True, "mode": h.get("mode"), "active_face": mem.get("active_face"),
                "visitor": (mem.get("visitor") or {}).get("name")}
    except (urllib.error.URLError, TimeoutError, ValueError, OSError) as e:
        return {"ok": False, "error": str(e)[:200]}


if __name__ == "__main__":
    mcp.run(transport="stdio")
