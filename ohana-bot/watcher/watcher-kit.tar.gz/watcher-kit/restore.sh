#!/usr/bin/env bash
# ʻOhana Watcher kit — put the loaner back EXACTLY as received.
#   ./restore.sh            # uses backup/watcher-factory-full.bin if present (exact image),
#                           # else Seeed's open-source V1.1.7 factory bins + your backup/nvsfactory.bin
#   PORT=/dev/cu.xxx ./restore.sh
set -u
cd "$(dirname "$0")"
ESP="python3 -m esptool"
BK="backup"
die(){ printf '\n\033[1;31mSTOP: %s\033[0m\n' "$*"; exit 1; }
say(){ printf '\n\033[1;36m%s\033[0m\n' "$*"; }

if [ -z "${PORT:-}" ]; then
  for p in $(ls /dev/cu.wchusbserial* /dev/cu.usbmodem* /dev/cu.usbserial* /dev/ttyACM* /dev/ttyUSB* 2>/dev/null); do
    $ESP --chip esp32s3 --port "$p" --no-stub --after no_reset chip_id 2>&1 | grep -q "Chip is ESP32-S3" && PORT="$p" && break
  done
  [ -n "${PORT:-}" ] || die "no ESP32-S3 port found (PORT=... ./restore.sh)"
fi
say "Port $PORT"

if [ -s "$BK/watcher-factory-full.bin" ]; then
  SZ=$(wc -c < "$BK/watcher-factory-full.bin" | tr -d ' ')
  [ "$SZ" = "33554432" ] || die "full image is $SZ bytes, expected 33554432"
  say "Restoring the exact 32 MB factory image (≈6 min)"
  printf 'Type RESTORE to continue: '; read -r a; [ "$a" = "RESTORE" ] || die aborted
  $ESP --chip esp32s3 --port "$PORT" --baud 921600 --before default_reset --after hard_reset \
       write_flash 0x0 "$BK/watcher-factory-full.bin" || die "write failed"
else
  [ -s "$BK/nvsfactory.bin" ] || die "no backup/nvsfactory.bin — without it the device identity is gone; do NOT continue"
  F="factory-v1.1.7"
  for f in bootloader/bootloader.bin partition_table/partition-table.bin ota_data_initial.bin factory_firmware.bin srmodels/srmodels.bin storage.bin; do
    [ -s "$F/$f" ] || die "missing $F/$f"
  done
  say "Restoring Seeed V1.1.7 factory firmware (Seeed's published addresses) + your nvsfactory identity"
  printf 'Type RESTORE to continue: '; read -r a; [ "$a" = "RESTORE" ] || die aborted
  $ESP --chip esp32s3 --port "$PORT" --baud 921600 --before default_reset --after no_reset \
       erase_flash || die "erase failed"
  $ESP --chip esp32s3 --port "$PORT" --baud 921600 --before default_reset --after no_reset \
       write_flash --flash_mode dio --flash_size 32MB --flash_freq 80m \
       0x0 "$F/bootloader/bootloader.bin" 0x8000 "$F/partition_table/partition-table.bin" \
       0x9000 "$BK/nvsfactory.bin" \
       0x10d000 "$F/ota_data_initial.bin" 0x110000 "$F/factory_firmware.bin" \
       0x1910000 "$F/srmodels/srmodels.bin" 0x1a10000 "$F/storage.bin" || die "write failed"
  $ESP --chip esp32s3 --port "$PORT" --after hard_reset --no-stub chip_id >/dev/null 2>&1
fi
say "Restored. Hold the wheel ~3 s to power on; the Seeed logo should appear. Himax chip was never touched."
